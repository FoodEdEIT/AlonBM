// הדביקו כאן את ההגדרות מ-Firebase (ראו את README.md).
// החליפו את כל הבלוק שמתחיל ב-window.FIREBASE_CONFIG.
window.FIREBASE_CONFIG = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  databaseURL: "https://YOUR_PROJECT-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "YOUR_PROJECT",
  appId: "YOUR_APP_ID"
};
// שם החדר. אפשר להשאיר כמו שזה.
window.GAME_ID = "alon";
